import { createQueue } from "./createQueue";

export const instructionQueue = createQueue("instructionQueue");
