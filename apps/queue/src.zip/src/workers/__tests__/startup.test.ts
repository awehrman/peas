import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { createNoteWorker } from "../note";
import { startWorkers } from "../startup";

// Mock worker factory
vi.mock("../note", () => ({
  createNoteWorker: vi.fn(),
}));

describe("startWorkers", () => {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Test mock
  let mockQueues: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Test mock
  let mockServiceContainer: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Test mock
  let mockLogger: any;

  beforeEach(() => {
    // Reset all mocks
    vi.clearAllMocks();

    // Create mock logger
    mockLogger = {
      log: vi.fn(),
    };

    // Create mock service container
    mockServiceContainer = {
      logger: mockLogger,
      _workers: {},
    };

    // Create mock queues
    mockQueues = {
      noteQueue: { name: "note-queue" },
    };

    // Mock worker factory returns
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Test mock
    (createNoteWorker as any).mockReturnValue({ name: "note-worker" });
  });

  afterEach(() => {
    vi.restoreAllMocks();
  });

  it("should create and start note worker successfully", () => {
    startWorkers(mockQueues, mockServiceContainer);

    // Verify worker factory was called with correct parameters
    expect(createNoteWorker).toHaveBeenCalledWith(
      mockQueues.noteQueue,
      mockServiceContainer
    );

    // Verify success message was logged
    expect(mockLogger.log).toHaveBeenCalledWith(
      "✅ note_processing worker created and started"
    );
  });

  it("should store worker in service container for graceful shutdown", () => {
    startWorkers(mockQueues, mockServiceContainer);

    // Verify worker is stored in the service container
    expect(mockServiceContainer._workers).toEqual({
      noteWorker: { name: "note-worker" },
    });
  });

  it("should handle errors during worker creation", () => {
    const error = new Error("Failed to create note worker");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Test mock
    (createNoteWorker as any).mockImplementation(() => {
      throw error;
    });

    // Should throw the error
    expect(() => {
      startWorkers(mockQueues, mockServiceContainer);
    }).toThrow("Failed to create note worker");

    // Should log the error
    expect(mockLogger.log).toHaveBeenCalledWith(
      "❌ Failed to create note_processing worker: Failed to create note worker",
      "error"
    );
  });

  it("should handle non-Error exceptions", () => {
    const error = "String error";
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Test mock
    (createNoteWorker as any).mockImplementation(() => {
      throw error;
    });

    // Should throw the error
    expect(() => {
      startWorkers(mockQueues, mockServiceContainer);
    }).toThrow("String error");

    // Should log the error
    expect(mockLogger.log).toHaveBeenCalledWith(
      "❌ Failed to create note_processing worker: Unknown error",
      "error"
    );
  });

  it("should not store worker if an error occurs", () => {
    const error = new Error("Failed to create worker");
    // eslint-disable-next-line @typescript-eslint/no-explicit-any -- Test mock
    (createNoteWorker as any).mockImplementation(() => {
      throw error;
    });

    expect(() => {
      startWorkers(mockQueues, mockServiceContainer);
    }).toThrow();

    // Worker should not be stored if an error occurs
    expect(mockServiceContainer._workers).toEqual({});
  });
});
