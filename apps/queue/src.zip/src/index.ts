import { SERVER_CONSTANTS, SERVER_DEFAULTS } from "./config";
import "./load-env";
import { healthRouter, importRouter, notesRouter, testRouter } from "./routes";
import { ServiceContainer } from "./services";
import { ErrorSeverity, ErrorType } from "./types";
import { initializeWebSocketServer } from "./websocket-server";

import { createBullBoard } from "@bull-board/api";
import { BullMQAdapter } from "@bull-board/api/bullMQAdapter.js";
import { ExpressAdapter } from "@bull-board/express";
import cors from "cors";
import express from "express";

import { startWorkers } from "./workers/startup";

async function initializeApp() {
  const serviceContainer = await ServiceContainer.getInstance();

  const app = express();

  // Enhanced error handling middleware
  app.use((req, res, next) => {
    const startTime = Date.now();

    res.on("finish", () => {
      const duration = Date.now() - startTime;
      const status = res.statusCode;

      if (status >= 400) {
        serviceContainer.logger.log(
          `⚠️ ${req.method} ${req.path} - ${status} (${duration}ms)`,
          "warn"
        );
      } else {
        serviceContainer.logger.log(
          `✅ ${req.method} ${req.path} - ${status} (${duration}ms)`
        );
      }
    });

    next();
  });

  app.use(cors());

  app.use(express.json({ limit: SERVER_DEFAULTS.REQUEST_SIZE_LIMIT }));

  app.use(
    (
      error: unknown,
      req: express.Request,
      res: express.Response,
      _next: express.NextFunction
    ) => {
      const jobError = serviceContainer.errorHandler.classifyError(
        error as Error
      );
      jobError.context = {
        ...((jobError.context as Record<string, unknown>) || {}),
        path: req.path,
        method: req.method,
        userAgent: req.get("User-Agent"),
      };

      serviceContainer.errorHandler.logError(jobError);

      res.status(500).json({
        error: {
          message: jobError.message,
          type: jobError.type,
          code: jobError.code,
        },
        timestamp:
          (jobError.timestamp as Date)?.toISOString() ||
          new Date().toISOString(),
      });
    }
  );

  // Bull-Board setup with error handling
  const serverAdapter = new ExpressAdapter();
  try {
    createBullBoard({
      queues: [
        new BullMQAdapter(serviceContainer.queues.noteQueue),
        // TODO: Add back other queues as needed
        // new BullMQAdapter(serviceContainer.queues.imageQueue),
        // new BullMQAdapter(serviceContainer.queues.ingredientQueue),
        // new BullMQAdapter(serviceContainer.queues.instructionQueue),
        // new BullMQAdapter(serviceContainer.queues.categorizationQueue),
        // new BullMQAdapter(serviceContainer.queues.sourceQueue),
      ],
      serverAdapter,
    });

    serverAdapter.setBasePath("/bull-board");
    app.use("/bull-board", serverAdapter.getRouter());
  } catch (error) {
    const jobError = serviceContainer.errorHandler.createJobError(
      error as Error,
      ErrorType.EXTERNAL_SERVICE_ERROR,
      ErrorSeverity.HIGH,
      { operation: "bull_board_setup" }
    );
    serviceContainer.errorHandler.logError(jobError);
    serviceContainer.logger.log(
      "Failed to setup Bull Board, continuing without it",
      "error"
    );
  }

  return { app, serviceContainer };
}

// Start the application
initializeApp()
  .then(({ app, serviceContainer }) => {
    // Health check endpoint with monitoring
    app.get("/health", async (req, res) => {
      try {
        const health =
          await serviceContainer.healthMonitor.healthMonitor.getHealth();

        const statusCode =
          health.status === "healthy"
            ? 200
            : health.status === "degraded"
              ? 200
              : SERVER_CONSTANTS.STATUS_CODES.SERVICE_UNAVAILABLE;

        res.status(statusCode).json(health);
      } catch (error) {
        const jobError = serviceContainer.errorHandler.createJobError(
          error as Error,
          ErrorType.EXTERNAL_SERVICE_ERROR,
          ErrorSeverity.HIGH,
          { operation: "health_check_endpoint" }
        );
        serviceContainer.errorHandler.logError(jobError);

        res.status(503).json({
          status: "unhealthy",
          message: "Health check failed",
          error: jobError.message,
          timestamp: new Date().toISOString(),
        });
      }
    });

    // Routes
    app.use("/import", importRouter);
    app.use("/notes", notesRouter);
    app.use("/health", healthRouter);
    app.use("/test", testRouter);

    // 404 handler
    app.use("*", (req, res) => {
      res.status(404).json({
        error: "Not Found",
        message: `Route ${req.method} ${req.originalUrl} not found`,
        timestamp: new Date().toISOString(),
      });
    });

    // Graceful shutdown handler
    const gracefulShutdown = async (signal: string) => {
      serviceContainer.logger.log(
        `🛑 Received ${signal}. Starting graceful shutdown...`,
        "info"
      );

      try {
        await serviceContainer.close();
        serviceContainer.logger.log(
          "✅ Graceful shutdown completed successfully",
          "info"
        );
        // eslint-disable-next-line no-process-exit
        process.exit(0);
      } catch (error) {
        const jobError = serviceContainer.errorHandler.createJobError(
          error as Error,
          ErrorType.UNKNOWN_ERROR,
          ErrorSeverity.CRITICAL,
          { operation: "graceful_shutdown" }
        );
        serviceContainer.errorHandler.logError(jobError);
        // eslint-disable-next-line no-process-exit
        process.exit(1); // Exit with error code instead of throwing
      }
    };

    // Start the server
    const server = app.listen(serviceContainer.config.port, () => {
      serviceContainer.logger.log(
        `🚀 Server running on port ${serviceContainer.config.port}`,
        "info"
      );
      serviceContainer.logger.log(
        `📊 Health check available at http://localhost:${serviceContainer.config.port}/health`,
        "info"
      );
      serviceContainer.logger.log(
        `🔧 Bull Board available at http://localhost:${serviceContainer.config.port}/bull-board`,
        "info"
      );
      serviceContainer.logger.log(
        `📡 WebSocket server starting on port ${serviceContainer.config.wsPort}`,
        "info"
      );
    });

    // Initialize WebSocket server
    initializeWebSocketServer(serviceContainer.config.wsPort);

    // Start workers
    startWorkers(serviceContainer.queues, serviceContainer);

    // Handle server errors
    server.on("error", (error) => {
      const jobError = serviceContainer.errorHandler.createJobError(
        error,
        ErrorType.NETWORK_ERROR,
        ErrorSeverity.CRITICAL,
        { operation: "server_startup" }
      );
      serviceContainer.errorHandler.logError(jobError);
      // eslint-disable-next-line no-process-exit
      process.exit(1); // Exit with error code instead of throwing
    });

    // Handle uncaught exceptions
    process.on("uncaughtException", (error) => {
      const jobError = serviceContainer.errorHandler.createJobError(
        error,
        ErrorType.UNKNOWN_ERROR,
        ErrorSeverity.CRITICAL,
        { operation: "uncaught_exception" }
      );
      serviceContainer.errorHandler.logError(jobError);
      gracefulShutdown("uncaught exception");
    });

    // Handle unhandled promise rejections
    process.on("unhandledRejection", (reason, promise) => {
      const jobError = serviceContainer.errorHandler.createJobError(
        reason as Error,
        ErrorType.UNKNOWN_ERROR,
        ErrorSeverity.CRITICAL,
        { operation: "unhandled_rejection", promise: promise.toString() }
      );
      serviceContainer.errorHandler.logError(jobError);
      gracefulShutdown("unhandled rejection");
    });

    // Handle graceful shutdown signals
    process.on("SIGTERM", () => gracefulShutdown("SIGTERM"));
    process.on("SIGINT", () => gracefulShutdown("SIGINT"));
  })
  .catch((error) => {
    console.error("Failed to initialize application:", error);
    // eslint-disable-next-line no-process-exit
    process.exit(1);
  });
