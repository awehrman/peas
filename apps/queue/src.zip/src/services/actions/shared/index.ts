// Shared actions that can be used across multiple workers
// TODO: Add shared actions like save-note, broadcast-status, etc.
