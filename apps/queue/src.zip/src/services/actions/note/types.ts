import type { Queue } from "bullmq";

// Import types from schemas to ensure consistency
import type {
  ParseHtmlData,
  ParsedHtmlFile,
  SaveNoteData,
  NoteJobData as SchemaNoteJobData,
} from "../../../schemas";
import type {
  BaseWorkerDependencies,
  WorkerAction,
} from "../../../workers/types";

/**
 * Result type for note processing operations
 */
export interface NoteProcessingResult {
  noteId: string;
  status: "completed" | "failed" | "partial";
  parsedLines: number;
  errors?: string[];
  duration?: number;
}

/**
 * Job data for note processing jobs
 * Use the schema-defined type for consistency
 */
export type NoteJobData = SchemaNoteJobData;

/**
 * Dependencies required by note worker actions
 */
export interface NoteWorkerDependencies extends BaseWorkerDependencies {
  // Database operations
  createNote: (file: ParsedHtmlFile) => Promise<NoteWithParsedLines>;
  createNoteCompletionTracker: (
    noteId: string,
    totalJobs: number
  ) => Promise<Record<string, unknown>>;

  // Parser operations
  parseHTML: (content: string) => Promise<ParsedHtmlFile>;

  // Queue operations (optional for future use)
  ingredientQueue?: Queue;
  instructionQueue?: Queue;
  imageQueue?: Queue;
  categorizationQueue?: Queue;
  sourceQueue?: Queue;

  // Logger with specific methods
  logger: {
    log: (
      message: string,
      level?: string,
      meta?: Record<string, unknown>
    ) => void;
  };

  // Status broadcasting
  addStatusEventAndBroadcast: (event: Record<string, unknown>) => Promise<void>;
}

// NoteWithParsedLines type definition
export interface NoteWithParsedLines {
  id: string;
  title: string | null;
  content: string;
  html: string;
  imageUrl?: string;
  createdAt: Date;
  updatedAt: Date;
  parsedIngredientLines: Array<{
    id: string;
    reference: string;
    blockIndex: number;
    lineIndex: number;
  }>;
  parsedInstructionLines: Array<{
    id: string;
    originalText: string;
    lineIndex: number;
  }>;
}

/**
 * Action names for note processing
 */
export enum NoteActionName {
  PARSE_HTML = "parse_html",
  CLEAN_HTML = "clean_html",
  SAVE_NOTE = "save_note",
}

/**
 * Pipeline action type for note processing
 */
export type NotePipelineAction = WorkerAction<
  NoteJobData,
  NoteWorkerDependencies,
  NoteProcessingResult
>;

// Re-export schema types for convenience
export type { ParseHtmlData, ParsedHtmlFile, SaveNoteData };
