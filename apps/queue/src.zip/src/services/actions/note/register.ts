import { CleanHtmlAction } from "./clean-html";
import { ParseHtmlAction } from "./parse-html";
import { SaveNoteAction } from "./save-note";
import type {
  NoteJobData,
  NoteProcessingResult,
  NoteWorkerDependencies,
} from "./types";

import { ActionFactory } from "../../../workers/core/action-factory";
import {
  createActionRegistration,
  registerActions,
} from "../../../workers/shared/action-registry";

/**
 * Register all note actions in the given ActionFactory with type safety
 */
export function registerNoteActions(
  factory: ActionFactory<
    NoteJobData,
    NoteWorkerDependencies,
    NoteProcessingResult
  >
): void {
  registerActions(factory, [
    createActionRegistration("parse_html", ParseHtmlAction),
    createActionRegistration("clean_html", CleanHtmlAction),
    createActionRegistration("save_note", SaveNoteAction),
  ]);
}
